Stan Catch
By LTV2008

How to play:
To play this game, simply click on the monster (his name is Stanley "Stan" Black) and the score will go up.

Other functions:
Esc: Quit.
F1: (F10 for Windows 10/11) Open help page. 
F2: Show high scores.
F4: Enter fullscreen.
F11: Clear all data.

Credits:
Music is from Scratch Sound Library (Video Game 2.wav - slowed down)
Sound effects and star background from GameMaker Library.

Art:
Brick border and Stan Black sprites are made by me.

Check out https://ltv2008.neocities.org/games for more games and software from LTV2008.